chrome.runtime.sendMessage('', {
  name: 'setLocalStorage',
  local: localStorage,
  url: window.location.href,
});
