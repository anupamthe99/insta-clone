function checkForLocalStorage() {
  chrome.runtime.sendMessage(
    { name: 'getLocalStorage', url: window.location.href },
    function(res) {
      console.log('resolved');
      Object.keys(res).map(function(key) {
        localStorage.setItem(key, res[key]);
      });

      return true;
    },
  );
}

checkForLocalStorage();
